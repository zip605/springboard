Employee Attrition & Satisfaction Analysis

Project Overview:
This project analyzes employee data to identify key factors contributing to attrition and predict which employees are at risk of leaving. It uses machine learning models to generate insights and support HR decision-making.

Files Included:
- Capstone_Two_Notebook.ipynb: Main notebook with data analysis, modeling, and results.
- Project_Report.pdf: Written summary of objectives, methodology, findings, and conclusions.
- Model_Metrics.csv: Table comparing model performance.
- README.md: This file.

Setup Instructions:
1. Download this folder to your computer.
2. Open Capstone_Two_Notebook.ipynb using Jupyter Notebook or Google Colab.
3. Install required libraries:
   pip install pandas numpy scikit-learn xgboost matplotlib seaborn
4. Run all cells to reproduce the analysis and model results.

Models Used:
- Logistic Regression
- Random Forest
- XGBoost
- Support Vector Machine (SVM)

Key Insights:
- Overtime and low job satisfaction are strong predictors of attrition.
- XGBoost performed best with the highest F1-score and ROC-AUC.
- Recommendations include improving career growth opportunities and reducing overtime hours.

Author:
Created by Zuraishe
Capstone Project — October 2025
Location: Orange Park, Florida, USA